<nav class="navbar navbar-expand-sm navbar-dark"
		style="background-color:purple;">
		<a class="navbar-brand" href="index.php">Fun Olympic 2023</a>
		<button class="navbar-toggler d-lg-none" type="button"
			data-toggle="collapse" data-target="#collapsibleNavId"
			aria-controls="collapsibleNavId" aria-expanded="false"
			aria-label="Toggle navigation"></button>
		<div class="collapse navbar-collapse" id="collapsibleNavId">
			<ul class="navbar-nav mr-auto mt-2 mt-lg-0">
				<li class="nav-item"><a class="nav-link" href="index.php">Home
						<span class="sr-only">(current)</span>
				</a></li>
				<li class="nav-item"><a class="nav-link" href="about-us.php">About us</a></li>
						<li class="nav-item dropdown">
						</a></li>
				<li class="nav-item"><a class="nav-link" href="photo-gallery.php">Photo
						Gallery</a></li>
						<li class="nav-item"><a class="nav-link" href="video-gallery.php">Live Videos</a></li>
						
				<li class="nav-item"><a class="nav-link" href="contact-us.php">Contact
						us</a></li>
						<li class="nav-item dropdown">
      
      </div>
    </li>

			</ul>
			<form class="form-inline my-2 my-lg-0">
				<a href="admit-now.php" class="btn btn-outline-success my-2 my-sm-0">Booking Ticket</a>
			</form>
		</div>
	</nav>