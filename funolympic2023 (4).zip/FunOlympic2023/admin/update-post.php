<?php
include '../config/connection.php';
if(isset($_GET['submit']))
{
    $a = $_GET['id1'];
    $b = $_GET['title1'];
    $c = $_GET['content1'];
    $d = $_GET['image1'];

    // Prepare the query
    $query = "UPDATE posts SET title=?, content=?, image=? WHERE id=?";
    $stmt = mysqli_prepare($conn, $query);
    
    // Bind the parameters
    mysqli_stmt_bind_param($stmt, "sssi", $b, $c, $d, $a);
    
    // Execute the statement
    $run = mysqli_stmt_execute($stmt);

    if($run)
    {
        header("location:view-post.php");
    }
    else
    {
        echo "<script>window.alert('Not updated')</script>";
    }
}
