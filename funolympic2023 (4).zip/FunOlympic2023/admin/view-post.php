<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("location:index.php");
    exit();
} else {
?>
<!doctype html>
<html lang="en">

<head>
    <title>Main Dashboard</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <!-- navbar start -->
    <nav class="navbar navbar-expand-sm navbar-dark" style="background-color:purple;">
        <a class="navbar-brand" href="main.php">Dashboard</a>
        <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId"
            aria-expanded="false" aria-label="Toggle navigation"></button>
        <div class="collapse navbar-collapse" id="collapsibleNavId">
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0">


            </ul>
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="#" style="text-transform:uppercase"><?php echo $_SESSION['username']; ?> <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Log Out</a>
                </li>
            </ul>


        </div>
    </nav>
    <!-- navbar end -->
    <!-- dashboard start -->
    <div class="container-fluid" style="padding:20px">
        <div class="row">
            <div class="col-md-4" style="background-color:gray;">
                <h2 class="display-4 text-center">Dashboard</h2>
                <a href="add-post.php" class="btn btn-danger btn-block btn-lg">Add New Post</a>
                <a href="view-post.php" class="btn btn-danger btn-block btn-lg">View All Post</a>
                <a href="view-booking.php" class="btn btn-danger btn-block btn-lg">View Bookings</a>
                <a href="view-comment.php" class="btn btn-danger btn-block btn-lg">View Comments</a>
                <a href="upload-photo.php" class="btn btn-danger btn-block btn-lg">Update Gallery</a>
                <a href="upload-video.php" class="btn btn-danger btn-block btn-lg">Upload Video</a>
            </div>
            <div class="col-md-8">
                <h2 class="display-4">View All Posts</h2>
                <?php
                include '../config/connection.php';

                // Delete post if "Del" parameter is set
                if (isset($_GET['Del'])) {
                    $post_id = $_GET['Del'];
                    $delete_query = "DELETE FROM posts WHERE id = '$post_id'";
                    $delete_result = mysqli_query($conn, $delete_query);

                    if ($delete_result) {
                        echo '<div class="alert alert-success">Post deleted successfully.</div>';
                    } else {
                        echo '<div class="alert alert-danger">Error deleting post.</div>';
                    }
                }

                $query = "SELECT * FROM posts";
                $run = mysqli_query($conn, $query);

                if (mysqli_num_rows($run) > 0) {
                    echo '
                    <table class="table table-dark table-hover table-bordered">
                        <thead>
                            <tr>
                                <th>POST ID</th>
                                <th>Title</th>
                                <th>Content</th>
                                <th>Photo</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>';

                    while ($row = mysqli_fetch_array($run)) {
                        $post_id = $row['id'];
                        $title = $row['title'];
                        $content = $row['content'];
                        $image = $row['image'];

                        echo '
                        <tr>
                            <td scope="row">' . $post_id . '</td>
                            <td>' . $title . '</td>
                            <td>' . $content . '</td>
                            <td><img src="../assets/images/' . $image . '" width="100px"></td>
                            <td><a class="btn btn-primary" href="edit.php?id=' . $post_id . '&title=' . $title . '&content=' . $content . '&image=' . $image . '">Edit</a></td>
                            <td><a class="btn btn-danger" href="view-post.php?Del=' . $post_id . '">Delete</a></td>
                        </tr>';
                    }

                    echo '
                        </tbody>
                    </table>';
                } else {
                    echo '<div class="alert alert-info">No posts found.</div>';
                }
                ?>
            </div>
        </div>
    </div>
    <!-- dashboard end -->
</body>

</html>
<?php
}
?>
