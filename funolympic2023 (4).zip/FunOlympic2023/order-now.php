<!doctype html>
<html lang="en">
  <head>
    <title>Welcome to Fun Olympic 2023</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Introduction of Coderly Media Creation, Services, Contact, Online Order, Online Payment">
    <meta name="keywords" content="Coderly Media Creation, Services, Contact, Online Order, Online Payment">
    <meta name="author" content="Coderly Chaudhary">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <link rel="shortcut icon" href="images/favicon.PNG" type="image/x-icon">
    <link rel="stylesheet" href="css/mystyle.css">
  </head>
  <body>
   <!-- navbar start -->
	<?php 
	include 'navbar.php';
	?>
	<!-- navbar end -->
    
    <!-- welcome start -->
    <div class="jumbotron jumbotron-fluid">
        <div class="container">
            <h1 class="display-3">Student admission form</h1>
            <hr class="my-2">
        </div>
    </div>
    <!-- welcome end -->
    <!-- content start -->
    <div class="container" style="padding: 40px;">
        <div class="row">
        <?php
        include 'admin/connection.php';
        if(isset($_GET['id']))
        {
        $itemid=$_GET['id'];
        $query="select * from orders where id='$itemid'";
        $run=mysqli_query($conn,$query);
        while($row=mysqli_fetch_array($run))
                {
                    $b=$row['title'];
                    $c=$row['content'];
                    $d=$row['image'];
        ?>
            <div class="col-md-9">
                <form action="send-order.php" method="post">

                    <div class="form-group">
                      <label for="fname">First Name:</label>
                      <input type="text" name="fname" id="fname" class="form-control" placeholder="First Name" aria-describedby="helpId" required autofocus>
                      <small id="helpId" class="text-muted"></small>
                    </div>

                    <div class="form-group">
                      <label for="lname">Last Name:</label>
                      <input type="text" name="lname" id="lname" class="form-control" placeholder="Last Name" aria-describedby="helpId" required>
                      <small id="helpId" class="text-muted"></small>
                    </div>

                    <div class="form-group">
                        <label for="address">Address:</label>
                        <input type="text" class="form-control" name="address" id="address" aria-describedby="helpId" placeholder="Address" required>
                      </div>
                    <!-- phone -->
                    <div class="form-group">
                        <label for="phone">Phone:</label>
                        <input type="text" class="form-control" name="phone" id="phone" aria-describedby="helpId" placeholder="Phone" required>
                      </div>
                    <!-- email -->
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" name="email" id="email" aria-describedby="helpId" placeholder="email" required>
                      </div>

                      <div class="form-group">
                        <label for="product">Product:</label>
                        <input type="text" class="form-control" name="product" id="email" aria-describedby="helpId" placeholder="email" required value="<?php echo $b; ?>">
                      </div>

                      <div class="form-group">
                        <label for="price">Price:</label>
                        <input type="text" class="form-control" name="price" id="email" aria-describedby="helpId" placeholder="email" required value="<?php echo $c; ?>"> 
                      </div>
                   
                    <!-- submit b4-form-submit -->
                    <button type="submit" class="btn btn-success btn-lg" name="submit">Check Out</button>
                    <!-- cancel b4-form-reset -->
                    <button type="reset" class="btn btn-danger btn-lg">Cancel</button>
                

                </form>
                <?php 
                }
            }
                ?>
                
            </div>
            <div class="col-md-3">
                <img src="images/slide2.webp" alt="add" class="img-thumbnail">
                <img src="images/slide3.jfif" alt="add" class="img-thumbnail">
                <img src="images/add.jpg" alt="add" class="img-thumbnail">
                <img src="images/ggg.webp" alt="add" class="img-thumbnail">

            </div>
        </div>
    </div>
    <!-- content end -->
    <!-- footer start -->
    <?php 
    include 'footer.php';
    ?>
    <!-- footer end -->
  </body>
</html>