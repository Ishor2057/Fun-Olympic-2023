<!doctype html>
<html lang="en">
  <head>
    <title>Welcome to Fun Olympic 2023</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Introduction of Fun Olympic 2023, Services, Contact, Online Order, Online Payment">
    <meta name="keywords" content="Fun Olympic 2023, Services, Contact, Online Order, Online Payment">
    <meta name="author" content="Ishor Pangeni">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <link rel="shortcut icon" href="images/favicon.PNG" type="image/x-icon">
    <link rel="stylesheet" href="css/mystyle.css">
  </head>
  <body>
   <!-- navbar start -->
	<?php 
	include 'header.php';
	?>
	<!-- navbar end -->    
    <!-- welcome start -->
    <div class="jumbotron jumbotron-fluid">
        <div class="container">
            <h1 class="display-3">About us</h1>
            <hr class="my-2">
        </div>
    </div>
    <!-- welcome end -->
    <!-- content start -->
    <div class="container" style="padding: 40px;">
        <div class="row">
            <div class="col-md-9">
                <h2>About Olympic</h2>
                <p>
                The Olympic Games have a rich and storied history that spans from ancient times to the present day. Originating in ancient Greece around the 8th century BCE,
                 the Olympics were held every four years in honor of the Greek god Zeus. The ancient Games featured a variety of athletic competitions, including running, 
                 wrestling, chariot racing, and discus throwing. It gained widespread popularity and attracted participants from various city-states across Greece. However, 
                 the ancient Olympics came to an end in 393 CE when they were banned by the Roman Emperor Theodosius I.</p>

                <p>It wasn't until the late 19th century that the Olympics were revived. Inspired by the ancient Games, Pierre de Coubertin, a French educator, spearheaded 
                    the modern Olympic movement. The inaugural modern Olympic Games took place in Athens, Greece, in 1896, featuring 280 athletes from 13 nations participating
                     in nine sports. Since then, the Olympics have grown significantly in scale and scope. Today, the Olympics are held every four years, alternating between 
                     the Summer and Winter Games. The event has become a global phenomenon, showcasing the world's best athletes and promoting peace and unity among nations.</p>

                <p>The most recent Summer Olympics were held in Tokyo, Japan, in 2021 (postponed from 2020 due to the COVID-19 pandemic). It saw the participation of over
                     11,000 athletes from 206 National Olympic Committees competing in 33 sports. The Games showcased incredible feats of athleticism and provided a platform 
                     for athletes from diverse backgrounds to shine. In addition to athletic competitions, the Olympics have evolved to include ceremonies, art exhibitions, 
                     and cultural events, fostering cultural exchange and celebration. The Games have also made strides towards inclusivity, with the inclusion of para-athletes
                      in the Paralympic Games, which began in 1960. The impact of the Olympics extends beyond sports, with host cities investing heavily in infrastructure, 
                      tourism, and urban development to prepare for the Games. From its humble beginnings in ancient Greece to its modern-day incarnation, the Olympic 
                      Games continue to captivate the world, showcasing the extraordinary abilities and determination of athletes from around the globe while promoting peace, 
                      unity, and the pursuit of excellence.</p>
                </p>
                <img src="assets/images/slide8.jpg" alt="add" class="img-thumbnail">
                

                <h2>Our Vision</h2>
                <p>
                The vision of the Olympic Games is to inspire humanity and foster global unity through the power of sports, culture, and education. 
                It envisions a world where individuals are encouraged to push their physical and mental boundaries, realizing their full potential through dedication,
                 discipline, and perseverance. The Olympics aim to create a platform where athletes from all nations can come together to compete at the highest level
                  while promoting friendship, respect, and fair play. Beyond the competitive aspect, the Games aspire to promote cultural understanding and exchange, 
                  emphasizing the importance of cultural diversity and the unity of humanity. Education plays a vital role, teaching individuals the values of respect,
                   solidarity, and peace. In essence, the vision of the Olympic Games is to build a better world through sport, inspiring individuals, communities, 
                   and nations to embrace the Olympic values and work together towards a brighter future.
                </p>

                <h2>Our Mission</h2>
                <p>
                The mission of the Olympic Games is to promote and foster the values of excellence, friendship, and respect through sport. 
                It aims to bring together athletes from around the world in the spirit of fair play and healthy competition, transcending borders, cultures, and backgrounds. 
                The Olympics strive to inspire individuals to push their physical and mental limits, to demonstrate the power of dedication and perseverance, and to achieve 
                their highest potential. Additionally, the mission of the Olympics is to create a platform for global unity and understanding, where nations can come together,
                 celebrate diversity, and build lasting connections. Through the Olympic Games, the mission is to promote peace, cultural exchange, and mutual respect among 
                 all participating athletes and nations, leaving a positive and enduring impact on society.
                </p>
            </div>
            <div class="col-md-3">
            <img src="assets/images/slide8.jpg" alt="add" class="img-thumbnail">
<img src="assets/images/slide7.jpg" alt="add" class="img-thumbnail">
<img src="assets/images/slide6.jpg" alt="add" class="img-thumbnail">
<img src="assets/images/slide2.jpg" alt="add" class="img-thumbnail">
            </div>
        </div>
    </div>
    <!-- content end -->
    <!-- footer start -->
    <?php 
    include 'footer.php';
    ?>
    <!-- footer end -->
  </body>
</html>