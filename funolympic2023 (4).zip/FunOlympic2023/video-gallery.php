<?php 
session_start();
if(!isset($_SESSION['username']))
{
    header("location:admin/index.php");
}
else
{
?>
<!-- header start -->
<?php 
	include 'header.php';
	?>
	<!-- header end -->
  <!-- navbar end -->
	<div class="jumbotron jumbotron-fluid">
      <nav>
    <ul class="navbar-nav text-center" style="float:right">
            <li class="nav-item active">
                <a class="nav-link" href="profile.php" style="text-transform:uppercase; display:block; background-color:lightblue; padding:50px; border-radius:100px; font-size:20px; font-weight:bold; color:#fff;"><?php echo $_SESSION['username']; ?> <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php" style="text-transform:uppercase; display:block; color:black; font-weight:bold;">Log Out</a>
            </li>
           </ul>
</nav>
    <!-- welcome start -->
    <div class="jumbotron jumbotron-fluid">
      <nav>
    
</nav>
        <div class="container">
            <h1 class="display-3">Video Gallery</h1>
            <hr class="my-2">
        </div>
    </div>
    <!-- welcome end -->
    <!-- content start -->
    <div class="container" style="padding: 40px;">
        <div class="row">
            <div class="col-md-9">
                
                   
            <?php
          $dir=glob('assets/video/{*.mp4}',GLOB_BRACE);
          foreach($dir as $value)
          {
          ?>
          <h2>Watch Live <span class="badge badge-warning">New</span></h2>
          <div class="livebox" style="background-color:lightblue; padding:20px">
            <a href="<?php echo $value; ?>">
            <video src="<?php echo $value; ?>" alt="HNP" width="300px" height="200px" align="left" hspace="5px" vspace="5px" controls>
            <source src="<?php echo $value; ?>" type="video/mp4">
            <source src="<?php echo $value; ?>" type="video/ogg">
          </video>
          </a>
          </div>
          <?php 
          }
          ?>


            </div>
            <div class="col-md-3">
            <?php
                include 'rightbar.php'; 
                ?>

            </div>
        </div>
    </div>
    <!-- content end -->
    <!-- item end -->
	<div class="container">
    <h2 class="display-4">Viewers Comments:</h2>
    </div>
    <!-- comment to start display -->
    <?php
                include 'config/connection.php';
                $query="select * from comment order by rand() LIMIT 5";
                $run=mysqli_query($conn,$query);
                while($row=mysqli_fetch_array($run))
                {
                    $a=$row['id'];
                    $b=$row['user'];
                    $c=$row['date'];
                    $d=$row['comment'];
                    $e=$row['rate'];
                ?>
      <div class="container">
        
        <div class="row" style="margin:20px 0px; border:2px solid gray;">
          <div class="col-sm-2" style="text-transform:uppercase; display:block; background-color:#000; padding:10px; font-size:12px; font-weight:bold; color:#fff; text-align:center; border:2px solid gray;"><?php echo $b; ?></div>
          <div class="col-sm-6" style="text-transform:uppercase; display:block; background-color:gray; padding:10px; font-size:12px; font-weight:bold; color:#fff; border:2px solid gray;"><?php echo $d; ?></div>
          <div class="col-sm-2" style="text-transform:uppercase; display:block; background-color:gray; padding:10px; font-size:12px; font-weight:bold; color:#fff; border:2px solid gray;"><?php echo $c; ?></div>
          <div class="col-sm-2" style="text-transform:uppercase; display:block; background-color:black; padding:10px; font-size:12px; font-weight:bold; color:#fff; border:2px solid gray;" ><?php 
          if($e==1)
          {
          ?>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star"></span>
          <span class="fa fa-star"></span>
          <span class="fa fa-star"></span>
          <span class="fa fa-star"></span>
          <?php
          }
          else if($e==2)
          {
          ?>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star"></span>
          <span class="fa fa-star"></span>
          <span class="fa fa-star"></span>
          <?php 
          }
          else if($e==3)
          {
          ?>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star"></span>
          <span class="fa fa-star"></span>
          <?php 
          }
          else if($e==4)
          {
          ?>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star"></span>
          <?php  
          }
          else if($e==5)
          {
          ?>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <?php 
          }
          ?>

        </div>
        </div>
      </div>
      <?php 
                }
                ?>
    <!-- comment end to display -->
    <!-- comment start  -->
    <div class="container" style="padding:10px">
    <h2>Comments:</h2>
    <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group">
                  <label for="content"></label>
                  <textarea class="form-control" name="comment" id="content" rows="3" placeholder="Comment" required></textarea>
                </div>
                <div class="form-group">
                  <label for="Rating">Rating:</label>
                  <input type="text" class="form-control" name="rate" id="" aria-describedby="helpId" placeholder="1 to 5">
                </div>
                <button type="submit" class="btn btn-primary btn-lg" name="submit">Comment</button>
                <button type="reset" class="btn btn-danger btn-lg">Cancel</button>
    </form>
    <?php
    if(isset($_POST['submit']))
    {
      include 'config/connection.php';
      $user=$_SESSION['username'];
      $date=date('Y/m/d');
      $com=$_POST['comment'];
      $rate=$_POST['rate'];
      $query="insert into comment(user,date,comment,rate)values('$user','$date','$com','$rate')";
      $run=mysqli_query($conn,$query);
      if($run)
                {
                    echo "<script>window.alert('Comment Added Successfully!')</script>";
                    echo "<script>window.open('video-gallery.php','_self')</script>";
                    
                }
                else
                {
                    echo "<script>window.alert('Error Found!')</script>";
                }
    }
    ?>
    </div>
    <!-- comment end -->
    <!-- footer start -->
    <?php 
    include 'footer.php';
    ?>
    <!-- footer end -->
    <?php 
}
?>