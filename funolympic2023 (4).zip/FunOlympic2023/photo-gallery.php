<!-- header start -->
<?php 
	include 'header.php';
	?>
	<!-- header end -->
    <!-- welcome start -->
    <div class="jumbotron jumbotron-fluid">
        <div class="container">
            <h1 class="display-3">Photo Gallery</h1>
            <hr class="my-2">
        </div>
    </div>
    <!-- welcome end -->
    <!-- content start -->
    <div class="container" style="padding: 40px;">
        <div class="row">
            <div class="col-md-9">
                
                <?php
          $dir=glob('assets/img/{*.jpg, *.png, *.jpeg}',GLOB_BRACE);
          foreach($dir as $value)
          {
          ?>
          <a href="<?php echo $value; ?>">
            <img id="myImg" src="<?php echo $value; ?>" alt="HNP" width="300px" height="200px" align="left" hspace="5px" vspace="5px" class="thumbnail">
          </a>
          <!-- The Modal -->
<div id="myModal" class="modal">

<!-- The Close Button -->
<span class="close">&times;</span>

<!-- Modal Content (The Image) -->
<img class="modal-content" id="img01">

<!-- Modal Caption (Image Text) -->
<div id="caption"></div>
</div>
          <?php 
          }
          ?>


            </div>
            <div class="col-md-3">
            <?php
                include 'rightbar.php'; 
                ?>

            </div>
        </div>
    </div>
    <!-- content end -->
    <!-- footer start -->
    <?php 
    include 'footer.php';
    ?>
    <!-- footer end -->
  