<!doctype html>
<html lang="en">
  <head>
    <title>Welcome to Coderly Media Creation</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Introduction of Coderly Media Creation, Services, Contact, Online Order, Online Payment">
    <meta name="keywords" content="Coderly Media Creation, Services, Contact, Online Order, Online Payment">
    <meta name="author" content="Coderly Chaudhary">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <link rel="shortcut icon" href="images/favicon.PNG" type="image/x-icon">
    <link rel="stylesheet" href="css/mystyle.css">
  </head>
  <body>
    <!-- navbar start -->
    <!-- navbar start -->
	<?php 
	include 'navbar.php';
	?>
	<!-- navbar end -->
    
    <!-- welcome start -->
    <div class="jumbotron jumbotron-fluid">
        <div class="container">
            <h1 class="display-3">Our Services</h1>
            <hr class="my-2">
        </div>
    </div>
    <!-- welcome end -->
    <!-- content start -->
    <div class="container" style="padding: 40px;">
        <div class="row">
            <div class="col-md-9">
                <h2>Web Designing</h2>
                <p>
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quas iure animi deserunt temporibus nobis quis quia soluta autem hic explicabo! Dolor, sint quis harum veniam deserunt culpa laborum adipisci rem? Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quisquam fugiat, iste amet nesciunt dolorem, nam animi veritatis culpa pariatur corrupti facere aliquam qui, repellat illo architecto. Officiis cupiditate in sapiente. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sit enim voluptatum optio! A quidem doloremque minus deleniti ex quam nostrum maxime! Fugit nulla eos sint minus iste inventore quam! Atque? 
                </p>
                <img src="images/web.jpg" alt="photo" class="img-thumbnail">

                <h2>Desktop Application</h2>
                <p>
                    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ipsum aliquam pariatur rem accusamus deleniti accusantium minima sapiente nostrum dolore laudantium nisi commodi deserunt quaerat est tempora, adipisci molestiae impedit totam. Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam praesentium nostrum quasi saepe, animi repudiandae laudantium exercitationem necessitatibus, rem consectetur totam natus? Officia culpa facere, tenetur natus iure cum quas!
                </p>
                <img src="images/ggg.webp" alt="app" class="img-thumbnail">

                <h2>Mobile Application</h2>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam quam fuga, fugit obcaecati voluptas reiciendis voluptate assumenda commodi laboriosam magnam dicta cum, dolorem eum. Libero, quae! Quod, ad. Quae, cum! Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore sit magni ullam, quos odio nulla fugit minima qui nisi adipisci aliquam, consequuntur repellendus libero perferendis dolore exercitationem alias, illo sint! Lorem ipsum dolor sit amet consectetur adipisicing elit. Fuga animi ex inventore earum quibusdam maxime, expedita et quos voluptatem sunt! Ea similique vero expedita aliquam impedit commodi corporis atque? Odio.
                </p>
                <img src="images/ggg.webp" alt="app" class="img-thumbnail">

                <h2>Photography and Videography</h2>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt, distinctio voluptate dolorem nam a hic dolor vel, non neque voluptas voluptatum delectus perspiciatis at necessitatibus! Ad necessitatibus quis tempora corrupti. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Id culpa recusandae totam natus! Dicta magnam voluptatibus ducimus vero minima odit, quis atque. Quo qui natus ratione quibusdam? Quasi, delectus minus.
                </p>
                <img src="images/ggg.webp" alt="app" class="img-thumbnail">
            </div>
            <div class="col-md-3">
                <img src="images/slide2.webp" alt="add" class="img-thumbnail">
                <img src="images/slide3.jfif" alt="add" class="img-thumbnail">
                <img src="images/add.jpg" alt="add" class="img-thumbnail">
                <img src="images/ggg.webp" alt="add" class="img-thumbnail">

            </div>
        </div>
    </div>
    <!-- content end -->
<!-- footer start -->
<?php 
    include 'footer.php';
    ?>
    <!-- footer end -->
  </body>
</html>