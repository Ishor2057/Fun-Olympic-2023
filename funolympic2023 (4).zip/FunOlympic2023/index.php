	<!-- header start -->
	<?php 
	include 'header.php';
	?>
	<!-- header end -->
	<!-- slide start -->
	<div id="carouselId" class="carousel slide" data-ride="carousel">
		<ol class="carousel-indicators">
			<li data-target="#carouselId" data-slide-to="0" class="active"></li>
			<li data-target="#carouselId" data-slide-to="1"></li>
			
		</ol>
		<div class="carousel-inner" role="listbox">
			<div class="carousel-item active" style="height: 33em">
				<img src="assets/images/slide1.jpg" alt="First slide" class="w-100 h-100">
				<div class="carousel-caption d-none d-md-block">
					
					
				</div>
			</div>
			<div class="carousel-item" style="height: 33em">
				<img src="assets/images/slide3.jpg" alt="Second slide" class="w-100 h-100">
				<div class="carousel-caption d-none d-md-block">
					
				</div>
			</div>
			
			</div>
		</div>
		<a class="carousel-control-prev" href="#carouselId" role="button"
			data-slide="prev"> <span class="carousel-control-prev-icon"
			aria-hidden="true"></span> <span class="sr-only">Previous</span>
		</a> <a class="carousel-control-next" href="#carouselId" role="button"
			data-slide="next"> <span class="carousel-control-next-icon"
			aria-hidden="true"></span> <span class="sr-only">Next</span>
		</a>
	</div>
	<!-- slide end -->
	<!-- welcome start -->
	<div class="jumbotron jumbotron-fluid">
		<div class="container">
			<h1 class="display-3">Welcome to Fun Olympic 2023</h1>
			
			<hr class="my-2">
			<p>The Olympic Games have a storied history that spans centuries. Originating in ancient Greece as religious and athletic festivals dedicated to Zeus, the ancient Olympics were held for over a millennium before coming to an end. In 1896, Pierre de Coubertin revived the Games, marking the beginning of the modern Olympic era. Since then, the Olympics have grown exponentially, incorporating more sports, attracting participants from nations worldwide, and promoting ideals of peace and athletic excellence. Throughout history, there have been remarkable moments, such as Jesse Owens' triumph, the Miracle on Ice, and the extraordinary achievements of athletes like Michael Phelps and Usain Bolt. Today, the Olympic Movement continues to inspire and captivate the world, with both Summer and Winter Games held every two years, showcasing the pinnacle of sporting competition and unity among nations.</p>
			<p class="lead">
				<a class="btn btn-primary btn-lg" href="about-us.php" role="button">Read
					More</a>
			</p>
		</div>
	</div>
	<!-- welcome end -->
	<!-- offer start -->
	<div class="container" style="padding: 30px;">
		<h2 class="display-4 text-center">Ancient Olympic Details</h2>
		<p class="lead text-center">Details of ancient olympic</p>
		<hr class="my-2">
		<div class="row">

		<div class="col-md-4">
				<h2>First Olympic 1896</h2>
				<img src="assets/images/ggg.jpg" alt="add" class="img-thumbnail">
				<p>Athens 1896 Olympic Games, athletic festival held in Athens that took place April 6–15, 1896. The Athens Games were the first occurrence of the modern Olympic Games.
                   The first modern Olympic Games took place in Athens, Greece, from April 6 to 15, 1896. It involved 280 male athletes from 12 countries competing in 43 events 
				   across various sports such as athletics, cycling, swimming, gymnastics, weightlifting, wrestling, fencing, shooting, and tennis. The opening day attracted over
				   60,000 spectators, and the Greek royal family played a significant role in organizing and attending the Games. Hungary was the only country to send a national team,
				   while most participants were wealthy college students or club members intrigued by the novelty of the Olympics.</p>

			</div>
			<div class="col-md-4">
				<h2>Second Olympic 1900</h2>
				<img src="assets/images/abcd.png" alt="add" class="img-thumbnail">
				<p>The second modern Olympic Games were held in Paris, France, from May 14 to October 28, 1900.
 					The event coincided with the Exposition Universelle (World's Fair) and spanned over several months, making it less cohesive than the inaugural Games. 
					It featured a larger number of athletes, with approximately 1,000 participants from 24 countries. 
					The sporting events were diverse, including athletics, cycling, swimming, gymnastics, fencing, rowing, and more. 
					The Games also introduced new sports like cricket, croquet, and ballooning. 
					However, due to the lack of a centralized organization and limited publicity, the second Olympics were overshadowed by the Exposition Universelle,
					and many athletes were unaware that they were participating in the Olympic Games.</p>

			</div>
			<div class="col-md-4">
				<h2>Third Olympic 1904</h2>
				<img src="assets/images/1904.png" alt="add" class="img-thumbnail">
				 <p>The third modern Olympic Games took place in St. Louis, United States, from July 1 to November 23, 1904.
					It was part of the Louisiana Purchase Exposition, a major world's fair. 
					The Games faced significant challenges, including limited international participation and a lack of interest from European athletes due to the long travel distance. 
					Consequently, the majority of competitors were American. The sporting events included athletics, gymnastics, wrestling, weightlifting, fencing, and archery, among others.
					The Games also featured several unconventional and localized sports such as lacrosse, tug of war, and baseball. 
					Despite the shortcomings, the third Olympics marked the first time gold, silver, and bronze medals were awarded to the top three finishers in each event. 
					The event's association with the world's fair helped raise the profile of the Olympics, laying the groundwork for future Games to come.</p>

			</div>

		</div>
	</div>
	<!-- offer end -->
	<!-- why us start -->
	<div class="jumbotron jumbotron-fluid" style="margin: 0px">
		<div class="container">
			<h1 class="display-3">Upcoming Olympic Details....</h1>
			<hr class="my-2">
			<div class="row">
				<div class="col-md-8">
					<p>The 2024 Summer Olympics, also known as Paris 2024, is an upcoming international multi-sport event scheduled to take place from 
						July 26 to August 11, 2024. Paris, France, will serve as the main host city, with 16 other cities in Metropolitan France and one
						in Tahiti acting as subsites. Paris was awarded the Games in 2017, making it the second city to host the Summer Olympics three times.
						The event will coincide with the centenary of the 1924 Paris Olympics and mark the sixth Olympic games hosted by France. 
						The 2024 Olympics will introduce breaking (breakdancing) as a new Olympic event. The Games will return to the traditional four-year cycle,
						as the 2020 Tokyo Olympics were postponed to 2021 due to the COVID-19 pandemic. The official languages will be English and French. 
						The preparation for the Games has been accompanied by controversy surrounding the potential participation of Russian and Belarusian athletes,
						and the estimated cost of the Paris Olympics is $8.5 billion.</p>
				</div>
				<div class="col-md-4">
				<img src="assets/images/2024.png" alt="add" class="img-thumbnail">
				</div>
			</div>
		</div>
	</div>
	<!-- why us end -->
	
	<!-- offer start -->
	<div class="container" style="padding: 30px;">
		<h2 class="display-4 text-center">Current News and Events</h2>
		<hr class="my-2">
		<div class="row">
        <?php
        include 'config/connection.php';
        $query = "select * from posts order by rand() LIMIT 4";
        $run = mysqli_query($conn, $query);
        while ($row = mysqli_fetch_array($run)) {
            $a = $row['id'];
            $b = $row['title'];
            $c = $row['content'];
            $d = $row['image'];
            ?>
            <div class="col-md-4">
				<strong><?php echo $b; ?></strong>
				<img id="myImg" src="assets/images/<?php echo $d; ?>" alt="png" class="img-thumbnail">
				<p><?php echo substr($c,0,100); ?> ........ </p>
				<a href="post.php?id=<?php echo $a; ?>"
					class="btn btn-danger btn-lg">Read More</a>
			</div>
            <?php
        }
        ?>
        </div>
	</div>

	<!-- offer end -->
	<!-- footer start -->
    <?php 
    include 'footer.php';
    ?>
    <!-- footer end -->
