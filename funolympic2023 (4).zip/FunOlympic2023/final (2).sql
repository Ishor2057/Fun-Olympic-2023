-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 11, 2023 at 03:42 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `final`
--

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `id` int(11) NOT NULL,
  `user` varchar(100) NOT NULL,
  `date` varchar(50) NOT NULL,
  `comment` varchar(500) NOT NULL,
  `rate` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id`, `user`, `date`, `comment`, `rate`) VALUES
(1, 'rose', '2023/06/08', 'Nice Product', 2),
(6, 'syaron', '2023/06/09', 'Great Gadget', 4),
(8, 'Rupak', '2023/06/09', 'I like it. Good One', 4);

-- --------------------------------------------------------

--
-- Table structure for table `orderconfirm`
--

CREATE TABLE `orderconfirm` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `product` varchar(100) NOT NULL,
  `price` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orderconfirm`
--

INSERT INTO `orderconfirm` (`id`, `first_name`, `last_name`, `address`, `phone`, `email`, `product`, `price`) VALUES
(1, 'Syaron', 'Mahato', 'Tandi', '9865088603', 'syaron@gmail.com', 'Lenovo IdeaPad l3 2021', '44000');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `content` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `title`, `content`, `image`) VALUES
(1, 'Lenovo IdeaPad l3 2021', '44000', 'lenovo-ideapad-3-2020-price-nepal.jpg'),
(2, 'RODE NT2-A Microphone', '5000', 'rodent2a-price-in-nepal.jpg'),
(3, 'WD Green 120GB SSD', '420', 'ssd-price-in-nepal.jpg'),
(4, 'Boat Airpode', '£ 15', 'boat.png');

-- --------------------------------------------------------

--
-- Table structure for table `otp`
--

CREATE TABLE `otp` (
  `id` int(11) NOT NULL,
  `otp` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `otp`
--

INSERT INTO `otp` (`id`, `otp`) VALUES
(1, 65),
(2, 23),
(3, 67),
(4, 94),
(5, 76),
(6, 23),
(7, 93),
(8, 32),
(9, 57),
(10, 97),
(11, 78),
(12, 14),
(13, 75),
(14, 94);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) NOT NULL,
  `title` varchar(500) NOT NULL,
  `content` longtext NOT NULL,
  `image` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `content`, `image`) VALUES
(2, 'Ronaldo hits form in time for another go at familiar foe Atletico', '                                        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Minus quam aperiam nobis aut praesentium temporibus nisi omnis voluptates impedit earum maxime id cupiditate quo officia suscipit illum fuga, ipsa autem? Lorem, ipsum dolor sit amet consectetur adipisicing elit. Minus quam aperiam nobis aut praesentium temporibus nisi omnis voluptates impedit earum maxime id cupiditate quo officia suscipit illum fuga, ipsa autem?                                                                ', 'elon.jpg'),
(3, 'Elon Musk dances at the grand opening of new Tesla giga factory', '                    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Minus quam aperiam nobis aut praesentium temporibus nisi omnis voluptates impedit earum maxime id cupiditate quo officia suscipit illum fuga, ipsa autem? Lorem, ipsum dolor sit amet consectetur adipisicing elit. Minus quam aperiam nobis aut praesentium temporibus nisi omnis voluptates impedit earum maxime id cupiditate quo officia suscipit illum fuga, ipsa autem? Lorem, ipsum dolor sit amet consectetur adipisicing elit. Minus quam aperiam nobis aut praesentium temporibus nisi omnis voluptates impedit earum maxime id cupiditate quo officia suscipit illum fuga, ipsa autem?                                                  ', 'ronaldo.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `id` int(10) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `dob` date NOT NULL,
  `address` varchar(50) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `price` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`id`, `first_name`, `last_name`, `gender`, `dob`, `address`, `phone`, `email`, `price`) VALUES
(1, 'Rose', 'Chaudhary', 'Female', '2023-02-22', 'London', 440098877, 'eyedust2000@gmail.com', 'CCNA');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `FirstName`, `LastName`, `Username`, `Password`, `role`) VALUES
(1, 'Keshav', 'Chaudhary', 'admin', 'c6f057b86584942e415435ffb1fa93d4', 'administrator'),
(5, 'Rose', 'Shrestha', 'rose', '202cb962ac59075b964b07152d234b70', 'user'),
(6, 'Syaron', 'Mahato', 'syaron', '202cb962ac59075b964b07152d234b70', 'user'),
(7, 'James', 'Gomez', 'james', '202cb962ac59075b964b07152d234b70', 'administrator');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orderconfirm`
--
ALTER TABLE `orderconfirm`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `otp`
--
ALTER TABLE `otp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `orderconfirm`
--
ALTER TABLE `orderconfirm`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `otp`
--
ALTER TABLE `otp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
