<img src="assets/images/slide8.jpg" alt="add" class="img-thumbnail">
<img src="assets/images/slide7.jpg" alt="add" class="img-thumbnail">
<img src="assets/images/slide6.jpg" alt="add" class="img-thumbnail">
<img src="assets/images/slide2.jpg" alt="add" class="img-thumbnail">