<!-- header start -->
<?php 
	include 'header.php';
	?>
	<!-- header end -->
    
    <!-- welcome start -->
    <div class="jumbotron jumbotron-fluid">
        <div class="container">
            <h1 class="display-3">Contact us</h1>
            <hr class="my-2">
        </div>
    </div>
    <!-- welcome end -->
    <!-- content start -->
    <div class="container" style="padding: 40px;">
        <div class="row">
            <div class="col-md-9">
                <p>Fun Olympic 2023 <br>
                    Paris <br>
                    France </p>

                    <p>Owner <br>
                   Fun Olympic</p>

                    
                    <p>FunOlympic2023@gmail.com</p>

                

            </div>
            <div class="col-md-3">
            <?php
                include 'rightbar.php'; 
                ?>

            </div>
        </div>
    </div>
    <!-- content end -->
    <!-- footer start -->
    <?php 
    include 'footer.php';
    ?>
    <!-- footer end -->
  